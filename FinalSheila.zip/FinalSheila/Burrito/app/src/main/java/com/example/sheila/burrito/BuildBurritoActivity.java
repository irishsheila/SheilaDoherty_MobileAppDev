package com.example.sheila.burrito;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

public class BuildBurritoActivity extends AppCompatActivity {

    private String location;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_build_burrito);
    }

    public void findBurrito(View view){
        EditText nameBurrito = (EditText) findViewById(R.id.burritoName);
        String burritoNamed = nameBurrito.getText().toString();
        ToggleButton toggle = (ToggleButton) findViewById(R.id.toggleButton);
        boolean burritoType = toggle.isChecked();
        String burritoFilling;
        RadioGroup choice = (RadioGroup)findViewById(R.id.radioGroup);
        int choice_id = choice.getCheckedRadioButtonId();
        String foodChoice;
        ImageView food = (ImageView)findViewById(R.id.imageView);
        CheckBox salsaCheckBox = (CheckBox)findViewById(R.id.checkBox2);
        Boolean salsa = salsaCheckBox.isChecked();
        CheckBox creamCheckBox = (CheckBox)findViewById(R.id.checkBox3);
        Boolean sourCream = creamCheckBox.isChecked();
        CheckBox guacCheckBox = (CheckBox)findViewById(R.id.checkBox4);
        Boolean guacamole = guacCheckBox.isChecked();
        CheckBox cheeseCheckBox = (CheckBox)findViewById(R.id.checkBox);
        Boolean cheese = cheeseCheckBox.isChecked();
        String cheeseTop = "";
        String salsaTop = "";
        String guacTop = "";
        String creamTop = "";
        Spinner locationSelected = (Spinner) findViewById(R.id.spinner);
        location = String.valueOf(locationSelected.getSelectedItem());
        Switch gluten = (Switch) findViewById(R.id.switch1);
        Boolean GF = gluten.isChecked();
        String glutenFree = "";

        if(burritoType) { //if veggie
            if (choice_id == R.id.radioButton1) { //choice burrito
                burritoFilling = "veggies";
                foodChoice = "burrito";
                food.setImageResource(R.drawable.burrito);
                //set image
            } else { //if meat
                foodChoice = "taco";
                food.setImageResource(R.drawable.taco);
                //set image
                burritoFilling = "veggies";
            }
        }
        else{
            if (choice_id == R.id.radioButton1) { //choice burrito
                burritoFilling = "meat";
                foodChoice = "burrito";
                //set image
                food.setImageResource(R.drawable.burrito);
            } else { //if meat
                foodChoice = "taco";
                //set image
                food.setImageResource(R.drawable.taco);
                burritoFilling = "meat";
            }
        }

        if (cheese){
            cheeseTop = " cheese";
        }
        if (salsa){
            salsaTop = " salsa";
        }
        if (guacamole){
            guacTop = " guacamole";
        }
        if (sourCream){
            creamTop = " sour cream";
        }
        if (GF){
            glutenFree = " with a corn tortilla";
        }

        TextView burritoSelected = (TextView) findViewById(R.id.burritoTypeTextView);
        burritoSelected.setText("The " + burritoNamed + " is a " + foodChoice + glutenFree + " filled with " + burritoFilling +
        cheeseTop + salsaTop + guacTop + creamTop + " that you would like to eat at " + location);
    }

    public void loadFindBurrito (View view){
        Intent intent = new Intent(this, FindBurritoActivity.class);
        intent.putExtra("burritoLocation", location);
        startActivity(intent);
    }
}

