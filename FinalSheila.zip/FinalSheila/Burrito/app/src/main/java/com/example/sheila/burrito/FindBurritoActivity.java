package com.example.sheila.burrito;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import org.w3c.dom.Text;

public class FindBurritoActivity extends AppCompatActivity {

    private String burritoLocal;
    private String burritoURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_burrito);
        String eatHere;

        Intent intent = getIntent();
        burritoLocal = intent.getStringExtra("burritoLocation");
        TextView messageView = (TextView) findViewById(R.id.burritoLocalTextView);
        switch(burritoLocal){
            case "The Hill":
                eatHere = "Illegal Petes";
                burritoURL = "http://illegalpetes.com/";
                break;
            case "Pearl Street":
                eatHere = "Bartaco";
                burritoURL = "https://bartaco.com/";
                break;
            default:
                eatHere = "Chipotle";
                burritoURL = "https://www.chipotle.com/";
                break;
        }
        messageView.setText("You should check out " + eatHere);

        final ImageButton imageButton = (ImageButton) findViewById(R.id.imageButton);
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick (View view){
                loadWebsite(view);
            }
        };
        imageButton.setOnClickListener(onclick);
    }

    public void loadWebsite(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(burritoURL));
        startActivity(intent);
    }
}
