//
//  ViewController.swift
//  SheilasKids
//
//  Created by Sheila Doherty on 9/17/17.
//  Copyright © 2017 Sheila Doherty. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var allFourImage: UIImageView!
    
    @IBOutlet weak var imageControl: UISegmentedControl!
    
    @IBAction func changeInfo(_ sender: UISegmentedControl) {
        updateCaps()
        updateImage()
    }
    
    @IBOutlet weak var capitalSwitch: UISwitch!
    
    @IBAction func updateFont(_ sender: UISwitch) {
        updateCaps()
    }
    
    @IBOutlet weak var fontSizeLabel: UILabel!
    
    @IBAction func changeFontSize(_ sender: UISlider) {
        let fontSize = sender.value
        fontSizeLabel.text = String(format: "%.0f", fontSize)
        let fontSizeCGFloat = CGFloat(fontSize)
        titleLabel.font = UIFont.systemFont(ofSize: fontSizeCGFloat)
    }
    
    func updateImage() {
        if imageControl.selectedSegmentIndex == 0 {
            titleLabel.text = "Rebekah"
            titleLabel.textColor = UIColor.blue
            allFourImage.image = UIImage(named: "Rebekah")
        }
        else if imageControl.selectedSegmentIndex == 1 {
            titleLabel.text = "Lucas"
            titleLabel.textColor = UIColor.green
            allFourImage.image = UIImage(named: "Lucas")
        }
        else if imageControl.selectedSegmentIndex == 2 {
            titleLabel.text = "Tyler"
            titleLabel.textColor = UIColor.orange
            allFourImage.image = UIImage(named: "Tyler")
        }
        else if imageControl.selectedSegmentIndex == 3 {
            titleLabel.text = "Samantha"
            titleLabel.textColor = UIColor.magenta
            allFourImage.image = UIImage(named: "Samantha")
        }
    }
    
    func updateCaps(){
        if capitalSwitch.isOn {
            titleLabel.text = titleLabel.text?.uppercased()
        }else{
            titleLabel.text = titleLabel.text?.lowercased()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

