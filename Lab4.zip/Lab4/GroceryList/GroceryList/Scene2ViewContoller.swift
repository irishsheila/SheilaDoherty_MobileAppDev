//
//  Scene2ViewContoller.swift
//  GroceryList
//
//  Created by Sheila Doherty on 10/17/17.
//  Copyright © 2017 Sheila Doherty. All rights reserved.
//

import UIKit

class Scene2ViewContoller: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var userFood: UITextField!
    @IBOutlet weak var userCatagory: UITextField!
   
    override func viewDidLoad() {
        userFood.delegate = self
        userCatagory.delegate = self
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "doneGroceries" {
            let scene1ViewController = segue.destination as! ViewController
            if userFood.text!.isEmpty == false {
                scene1ViewController.user.food=userFood.text
            }
            if userCatagory.text!.isEmpty == false{
                scene1ViewController.user.catagory=userCatagory.text
            }
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
