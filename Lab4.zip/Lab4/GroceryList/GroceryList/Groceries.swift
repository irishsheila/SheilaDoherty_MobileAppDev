//
//  Groceries.swift
//  GroceryList
//
//  Created by Sheila Doherty on 10/17/17.
//  Copyright © 2017 Sheila Doherty. All rights reserved.
//

import Foundation

class Groceries {
    var food : String?
    var catagory : String?
}
