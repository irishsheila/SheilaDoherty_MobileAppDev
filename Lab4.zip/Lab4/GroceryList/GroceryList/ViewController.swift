//
//  ViewController.swift
//  GroceryList
//
//  Created by Sheila Doherty on 10/17/17.
//  Copyright © 2017 Sheila Doherty. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var foodLabel: UILabel!
    @IBOutlet weak var catagoryLabel: UILabel!
    
    var user = Groceries()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func unwindSegue(_ segue: UIStoryboardSegue){
        foodLabel.text=user.food
        catagoryLabel.text=user.catagory
    }


}

