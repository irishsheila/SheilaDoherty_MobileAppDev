//
//  ViewController.swift
//  bakeConvert
//
//  Created by Sheila Doherty on 10/12/17.
//  Copyright © 2017 Sheila Doherty. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {


    let mPickerData1 = ["Tablespoon", "Teaspoon", "Cup", "Ounce", "Pint", "Gallon", "Liter", "Milliliter"]
    let mPickerData2 = ["Tablespoon", "Teaspoon", "Cup", "Ounce", "Pint", "Gallon", "Liter", "Milliliter"]
    let amountPickerData1 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50]
    let amountPickerData2 = ["0", "1/8", "1/4", "1/3", "1/2", "2/3", "3/4"]

    
    @IBOutlet weak var measureDisplay2: UILabel!
    @IBOutlet weak var measureDisplay: UILabel!
    @IBOutlet weak var mPickerView2: UIPickerView!
    @IBOutlet weak var amountPicker2: UIPickerView!
    @IBOutlet weak var amountPicker1: UIPickerView!
    @IBOutlet weak var mPickerView1: UIPickerView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        mPickerView1.delegate = self
        mPickerView1.dataSource = self
        mPickerView2.delegate = self
        mPickerView2.dataSource = self
        amountPicker1.delegate = self
        amountPicker1.dataSource = self
        amountPicker2.delegate = self
        amountPicker2.dataSource = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        if pickerView == mPickerView1 {
            return 1
        }
        if pickerView == mPickerView2 {
            return 1
        }
        if pickerView == amountPicker1{
            return 1
        }
        else{
            return 1
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == mPickerView1 {
            return mPickerData1.count
        }
        if pickerView == mPickerView2 {
            return mPickerData2.count
        }
        if pickerView == amountPicker1 {
            return amountPickerData1.count
        }
        else {
            return amountPickerData2.count
        }
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == mPickerView1 {
            return mPickerData1[row]
        }
        if pickerView == mPickerView2 {
            return mPickerData2[row]
        }
        if pickerView == amountPicker1 {
            return "\(amountPickerData1[row])"
        }
        else {
            return (amountPickerData2[row])
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        updateLabel()
    }
    
    func updateLabel(){
        let measurement1 = mPickerData1[mPickerView1.selectedRow(inComponent: 0)]
        let measurement2 = mPickerData2[mPickerView2.selectedRow(inComponent: 0)]
        let convertAmount = amountPickerData2[amountPicker2.selectedRow(inComponent: 0)]
        var convertFloat : Float = 0.0
        
        if (convertAmount == "0"){
            convertFloat = 0.0
        }
        if (convertAmount == "1/8"){
            convertFloat = 1/8
        }
        if (convertAmount == "1/4"){
            convertFloat = 1/4
        }
        if (convertAmount == "1/3"){
            convertFloat = 1/3
        }
        if (convertAmount == "1/2"){
            convertFloat = 1/2
        }
        if (convertAmount == "2/3"){
            convertFloat = 2/3
        }
        if (convertAmount == "3/4"){
            convertFloat = 3/4
        }
        
        let unitAmount: Float = Float(amountPickerData1[amountPicker1.selectedRow(inComponent: 0)]) + convertFloat
        
        //CUPS******************************************************************************
        if (measurement1 == "Cup"){
            if (measurement2 == "Cup"){
                if (unitAmount <= 1) {
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Cup"
                    measureDisplay2.text = "\(String((unitAmount * 1000).rounded()/1000)) Cup"
                }
                else{
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Cups"
                    measureDisplay2.text = "\(String((unitAmount * 1000).rounded()/1000)) Cups"
                }
            }
            if (measurement2 == "Tablespoon"){
                let tablespoon: Float = 16
                let amount: Float = unitAmount * tablespoon
                if (unitAmount <= 1) {
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Cup"
                    measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoons"
                }
                else{
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Cups"
                    measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoons"
                }
            }
            if (measurement2 == "Teaspoon"){
                let teaspoon: Float = 48
                let amount: Float = unitAmount * teaspoon
                if (unitAmount <= 1) {
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Cup"
                    measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoons"
                }
                else{
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Cups"
                    measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoons"
                }
            }
            if (measurement2 == "Pint"){
                let pint: Float = 0.5
                let amount: Float = unitAmount * pint
                if (unitAmount <= 1) {
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Cup"
                    measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pint"
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Cups"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pint"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Cups"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pints"
                    }
                }
            }
            if (measurement2 == "Ounce"){
                let ounce: Float = 8
                let amount: Float = unitAmount * ounce
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Cup"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounce"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Cup"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounces"
                    }
                }
                else{
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Cups"
                    measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounces"
                }
            }
            if (measurement2 == "Gallon"){
                let gallon: Float = 0.0625
                let amount: Float = unitAmount * gallon
                if (unitAmount <= 1) {
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Cup"
                    measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallon"
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Cups"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Cup"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallons"
                    }
                }
            }
            if (measurement2 == "Liter"){
                let liter: Float = 0.236588
                let amount: Float = unitAmount * liter
                if (unitAmount <= 1) {
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Cup"
                    measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liter"
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Cups"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Cup"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liters"
                    }
                }
            }
            if (measurement2 == "Milliliter"){
                let milliliter: Float = 236.588
                let amount: Float = unitAmount * milliliter
                if (unitAmount <= 1) {
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Cup"
                    measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliters"
                }
                else{
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Cups"
                    measureDisplay2.text = "\(String((amount * 1000).rounded()/1000)) Milliliters"
                }
            }
            

        }
        //TABLESPOONS******************************************************************************
        if (measurement1 == "Tablespoon"){
            if (measurement2 == "Tablespoon"){
                if (unitAmount <= 1) {
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoon"
                    measureDisplay2.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoon"
                }
                else{
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoons"
                    measureDisplay2.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoons"
                }
            }
            if (measurement2 == "Cup"){
                let cup: Float = 0.0625
                let amount: Float = unitAmount * cup
                if (unitAmount <= 1) {
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoon"
                    measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cup"
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cup"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cups"
                    }
                }
            }
            if (measurement2 == "Teaspoon"){
                let teaspoon: Float = 3
                let amount: Float = unitAmount * teaspoon
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoons"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoons"
                    }
                }
            }
            if (measurement2 == "Pint"){
                let pint: Float = 0.03125
                let amount: Float = unitAmount * pint
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pint"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pints"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pint"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pints"
                    }
                }
            }
            if (measurement2 == "Ounce"){
                let ounce: Float = 0.5
                let amount: Float = unitAmount * ounce
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounce"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounces"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounce"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounces"
                    }
                }
            }
            if (measurement2 == "Gallon"){
                let gallon: Float = 0.00390625
                let amount: Float = unitAmount * gallon
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallons"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallons"
                    }
                }
            }
            if (measurement2 == "Liter"){
                let liter: Float = 0.0147868
                let amount: Float = unitAmount * liter
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liters"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liters"
                    }
                }
            }
            if (measurement2 == "Milliliter"){
                let milliliter: Float = 14.7868
                let amount: Float = unitAmount * milliliter
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliters"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Tablespoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliters"
                    }
                }

            }
        }
        //TEASPOONS******************************************************************************
        if (measurement1 == "Teaspoon"){
            if (measurement2 == "Teaspoon"){
                if (unitAmount <= 1) {
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoon"
                    measureDisplay2.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoon"
                }
                else{
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoons"
                    measureDisplay2.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoons"
                }
            }
            if (measurement2 == "Cup"){
                let cup: Float = 0.0208333
                let amount: Float = unitAmount * cup
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cup"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cups"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cup"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cups"
                    }
                }
            }
            if (measurement2 == "Tablespoon"){
                let tablespoon: Float = 0.333333
                let amount: Float = unitAmount * tablespoon
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoons"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoons"
                    }
                }
            }
            if (measurement2 == "Pint"){
                let pint: Float = 0.0104167
                let amount: Float = unitAmount * pint
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pint"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pints"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pint"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pints"
                    }
                }
            }
            if (measurement2 == "Ounce"){
                let ounce: Float = 0.166667
                let amount: Float = unitAmount * ounce
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounce"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounces"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounce"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounces"
                    }
                }
            }
            if (measurement2 == "Gallon"){
                let gallon: Float = 0.00130208
                let amount: Float = unitAmount * gallon
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallons"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallons"
                    }
                }
            }
            if (measurement2 == "Liter"){
                let liter: Float = 0.00492892
                let amount: Float = unitAmount * liter
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liters"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liters"
                    }
                }
            }
            if (measurement2 == "Milliliter"){
                let milliliter: Float = 4.92892
                let amount: Float = unitAmount * milliliter
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliters"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Teaspoons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliters"
                    }
                }
            }
        }
        //OUNCE******************************************************************************
        if (measurement1 == "Ounce"){
            if (measurement2 == "Ounce"){
                if (unitAmount <= 1) {
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounce"
                    measureDisplay2.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounce"
                }
                else{
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounces"
                    measureDisplay2.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounces"
                }
            }
            if (measurement2 == "Cup"){
                let cup: Float = 0.125
                let amount: Float = unitAmount * cup
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounce"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cup"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounce"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cups"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounces"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cup"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounces"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cups"
                    }
                }
            }
            if (measurement2 == "Tablespoon"){
                let tablespoon: Float = 2
                let amount: Float = unitAmount * tablespoon
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounce"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounce"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoons"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounces"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounces"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoons"
                    }
                }
            }
            if (measurement2 == "Pint"){
                let pint: Float = 0.0625
                let amount: Float = unitAmount * pint
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounce"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pint"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounce"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pints"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounces"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pint"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounces"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pints"
                    }
                }
            }
            if (measurement2 == "Teaspoon"){
                let teaspoon: Float = 6
                let amount: Float = unitAmount * teaspoon
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounce"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounce"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoons"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounces"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounces"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoons"
                    }
                }
            }
            if (measurement2 == "Gallon"){
                let gallon: Float = 0.0078125
                let amount: Float = unitAmount * gallon
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounce"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounce"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallons"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounces"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounces"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallons"
                    }
                }
            }
            if (measurement2 == "Liter"){
                let liter: Float = 0.0295735
                let amount: Float = unitAmount * liter
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounce"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounce"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liters"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounces"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounces"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liters"
                    }
                }
            }
            if (measurement2 == "Milliliter"){
                let milliliter: Float = 29.5735
                let amount: Float = unitAmount * milliliter
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounce"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounce"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliters"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounces"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Ounces"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliters"
                    }
                }
            }

        }
        //PINT******************************************************************************
        if (measurement1 == "Pint"){
            if (measurement2 == "Pint"){
                if (unitAmount <= 1) {
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pint"
                    measureDisplay2.text = "\(String((unitAmount * 1000).rounded()/1000)) Pint"
                }
                else{
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pints"
                    measureDisplay2.text = "\(String((unitAmount * 1000).rounded()/1000)) Pints"
                }
            }
            if (measurement2 == "Cup"){
                let cup: Float = 2
                let amount: Float = unitAmount * cup
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pint"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cup"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pint"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cups"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pints"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cup"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pints"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cups"
                    }
                }
            }
            if (measurement2 == "Tablespoon"){
                let tablespoon: Float = 32
                let amount: Float = unitAmount * tablespoon
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pint"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pint"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoons"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pints"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pints"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoons"
                    }
                }
            }
            if (measurement2 == "Teaspoon"){
                let teaspoon: Float = 96
                let amount: Float = unitAmount * teaspoon
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pint"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pint"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoons"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pints"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pints"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoons"
                    }
                }
            }
            if (measurement2 == "Ounce"){
                let ounce: Float = 16
                let amount: Float = unitAmount * ounce
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pint"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounce"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pint"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounces"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pints"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounce"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pints"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounces"
                    }
                }
            }
            if (measurement2 == "Gallon"){
                let gallon: Float = 0.125
                let amount: Float = unitAmount * gallon
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pint"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pint"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallons"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pints"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pints"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallons"
                    }
                }
            }
            if (measurement2 == "Liter"){
                let liter: Float = 0.473176
                let amount: Float = unitAmount * liter
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pint"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pint"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liters"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pints"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pints"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liters"
                    }
                }
            }
            if (measurement2 == "Milliliter"){
                let milliliter: Float = 473.176
                let amount: Float = unitAmount * milliliter
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pint"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pint"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliters"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pints"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Pints"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliters"
                    }
                }
            }
        }
        //GALLON******************************************************************************
        if (measurement1 == "Gallon"){
            if (measurement2 == "Gallon"){
                if (unitAmount <= 1) {
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallon"
                    measureDisplay2.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallon"
                }
                else{
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallons"
                    measureDisplay2.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallons"
                }
            }
            if (measurement2 == "Cup"){
                let cup: Float = 16
                let amount: Float = unitAmount * cup
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cup"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cups"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cup"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cups"
                    }
                }
            }
            if (measurement2 == "Tablespoon"){
                let tablespoon: Float = 256
                let amount: Float = unitAmount * tablespoon
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoons"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoons"
                    }
                }
            }
            if (measurement2 == "Teaspoon"){
                let teaspoon: Float = 768
                let amount: Float = unitAmount * teaspoon
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoons"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoons"
                    }
                }
            }
            if (measurement2 == "Ounce"){
                let ounce: Float = 128
                let amount: Float = unitAmount * ounce
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounce"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounces"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounce"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounces"
                    }
                }
            }
            if (measurement2 == "Pint"){
                let pint: Float = 8
                let amount: Float = unitAmount * pint
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pint"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pints"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pint"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pints"
                    }
                }
            }
            if (measurement2 == "Liter"){
                let liter: Float = 3.78541
                let amount: Float = unitAmount * liter
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liters"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liters"
                    }
                }
            }
            if (measurement2 == "Milliliter"){
                let milliliter: Float = 3785.41
                let amount: Float = unitAmount * milliliter
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliters"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallon"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Gallons"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliters"
                    }
                }
            }
        }
        //LITER******************************************************************************
        if (measurement1 == "Liter"){
            if (measurement2 == "Liter"){
                if (unitAmount <= 1) {
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liter"
                    measureDisplay2.text = "\(String((unitAmount * 1000).rounded()/1000)) Liter"
                }
                else{
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liters"
                    measureDisplay2.text = "\(String((unitAmount * 1000).rounded()/1000)) Liters"
                }
            }
            if (measurement2 == "Cup"){
                let cup: Float = 4.22675
                let amount: Float = unitAmount * cup
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cup"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cups"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cup"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cups"
                    }
                }
            }
            if (measurement2 == "Tablespoon"){
                let tablespoon: Float = 67.628
                let amount: Float = unitAmount * tablespoon
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoons"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoons"
                    }
                }
            }
            if (measurement2 == "Teaspoon"){
                let teaspoon: Float = 202.884
                let amount: Float = unitAmount * teaspoon
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoons"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoons"
                    }
                }
            }
            if (measurement2 == "Ounce"){
                let ounce: Float = 33.814
                let amount: Float = unitAmount * ounce
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounce"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounces"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounce"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounces"
                    }
                }
            }
            if (measurement2 == "Pint"){
                let pint: Float = 2.11338
                let amount: Float = unitAmount * pint
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pint"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pints"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pint"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pints"
                    }
                }
            }
            if (measurement2 == "Gallon"){
                let gallon: Float = 0.264172
                let amount: Float = unitAmount * gallon
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallons"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallons"
                    }
                }
            }
            if (measurement2 == "Milliliter"){
                let milliliter: Float = 1000
                let amount: Float = unitAmount * milliliter
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliters"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Liters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Milliliters"
                    }
                }
            }
        }
        //MILLILETER******************************************************************************
        if (measurement1 == "Milliliter"){
            if (measurement2 == "Milliliter"){
                if (unitAmount <= 1) {
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliter"
                    measureDisplay2.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliter"
                }
                else{
                    measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliters"
                    measureDisplay2.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliters"
                }
            }
            if (measurement2 == "Cup"){
                let cup: Float = 0.00422675
                let amount: Float = unitAmount * cup
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cup"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cups"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cup"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Cups"
                    }
                }
            }
            if (measurement2 == "Tablespoon"){
                let tablespoon: Float = 0.067628
                let amount: Float = unitAmount * tablespoon
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoons"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Tablespoons"
                    }
                }
            }
            if (measurement2 == "Teaspoon"){
                let teaspoon: Float = 0.202884
                let amount: Float = unitAmount * teaspoon
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoons"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Teaspoons"
                    }
                }
            }
            if (measurement2 == "Ounce"){
                let ounce: Float = 0.033814
                let amount: Float = unitAmount * ounce
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounce"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounces"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounce"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Ounces"
                    }
                }
            }
            if (measurement2 == "Pint"){
                let pint: Float = 0.00211338
                let amount: Float = unitAmount * pint
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pint"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pints"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pint"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Pints"
                    }
                }
            }
            if (measurement2 == "Gallon"){
                let gallon: Float = 0.000264172
                let amount: Float = unitAmount * gallon
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallons"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallon"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Gallons"
                    }
                }
            }
            if (measurement2 == "Liter"){
                let liter: Float = 0.001
                let amount: Float = unitAmount * liter
                if (unitAmount <= 1) {
                    if (amount <= 1) {
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliter"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liters"
                    }
                }
                else{
                    if (amount <= 1){
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liter"
                    }
                    else{
                        measureDisplay.text = "\(String((unitAmount * 1000).rounded()/1000)) Milliliters"
                        measureDisplay2.text = "\((amount * 1000).rounded()/1000) Liters"
                    }
                }
            }
        }
    }
}

