//
//  ViewController.swift
//  PetViewer
//
//  Created by Sheila Doherty on 9/10/17.
//  Copyright © 2017 Sheila Doherty. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var petViewer: UIImageView!
    
    @IBOutlet weak var petName: UILabel!
    @IBAction func buttonPressed(_ sender: UIButton) {
        if sender.tag == 1 {
            petViewer.image=UIImage(named: "Jayne")
            petName.text = "Jayne"
        }
        else if sender.tag == 2 {
            petViewer.image=UIImage(named: "Piper")
            petName.text = "Piper"
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

