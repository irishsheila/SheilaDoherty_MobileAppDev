package com.example.sheila.sortinghat;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Button answer1, answer2, answer3, answer4;
    TextView quizQuestion;

    private Questions mQuestions = new Questions();
    private int mAnswer1;
    private int mAnswer2;
    private int mAnswer3;
    private int mAnswer4;
    private int mScore = 0;
    private int mQuestionLength = mQuestions.sortingQuestions.length;
    private int mQuestionNumber = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //r = new Random();

        answer1 = (Button)findViewById(R.id.answer1);
        answer2 = (Button)findViewById(R.id.answer2);
        answer3 = (Button)findViewById(R.id.answer3);
        answer4 = (Button)findViewById(R.id.answer4);

        quizQuestion = (TextView)findViewById(R.id.quizQuestion);

        if (mQuestionNumber < mQuestionLength) {
            updateQuestion(mQuestionNumber);
        }
        else{
            //load the house announcement screen
        }

        answer1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mScore = mScore + mAnswer1;
                mQuestionNumber++;
                updateQuestion(mQuestionNumber);
            }
        });
        answer2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mScore = mScore + mAnswer2;
                mQuestionNumber++;
                updateQuestion(mQuestionNumber);
            }
        });
        answer3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mScore = mScore + mAnswer3;
                mQuestionNumber++;
                updateQuestion(mQuestionNumber);
            }
        });
        answer4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mScore = mScore + mAnswer4;
                mQuestionNumber++;
                updateQuestion(mQuestionNumber);
            }
        });
    }

    private void updateQuestion(int num){
        quizQuestion.setText(mQuestions.getQuestion(num));
        answer1.setText(mQuestions.getChoice1(num));
        answer2.setText(mQuestions.getChoice2(num));
        answer3.setText(mQuestions.getChoice3(num));
        answer4.setText(mQuestions.getChoice4(num));

        mAnswer1 = mQuestions.getScore1(num);
        mAnswer2 = mQuestions.getScore2(num);
        mAnswer3 = mQuestions.getScore3(num);
        mAnswer4 = mQuestions.getScore4(num);
    }
}
