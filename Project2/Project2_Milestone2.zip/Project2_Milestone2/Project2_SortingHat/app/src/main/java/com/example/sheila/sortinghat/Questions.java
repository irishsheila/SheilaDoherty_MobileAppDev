package com.example.sheila.sortinghat;

/**
 * Created by Sheila on 11/27/17.
 */

public class Questions {
    public String sortingQuestions[] = {
            //1
            "After you have died, what would you most like people to do when they hear your name?",
            //2
            "How would you like to be known to history?",
            //3
            "What are you most looking forward to learning at Hogwarts?",
            //4
            "If you could have any power, which would you choose?",
            //5
            "You are choosing your first wand at Ollivander's Wand Shop. What is the core?",
            //6
            "When arriving at Hogwarts, which of the following would you most like to study?",
            //7
            "Which would you rather be?",
            //8
            "You and two friends need to cross a bridge guarded by a river troll who insists on fighting one of you before he will let all of you pass. Do you:",
            //9
            "Which road tempts you most?",
            //10
            "Which nightmare would frighten you most?",
            //11
            "Late at night, walking alone down the street, you hear a peculiar cry that you believe to have a magical source. Do you:",
            //12
            "A Muggle confronts you and says that they are sure you are a witch or wizard. Do you:",
            //13
            "Given the choice, would you rather invent a potion that would guarantee you:"
    };

    private String sortingChoices[][] = {
            //1: G,R,H,S
            {"Ask for more stories about your adventures", "Think with admiration of your achievements", "Miss you, but smile", " I don’t care what people think of me after I’m dead; it’s what they think of me while I’m alive that counts"},
            //2: H,S,R,G
            {"The Good", "The Great", "The Wise", "The Bold"},
            //3: S,G,H,R
            {"Hexes and jinxes", "Flying on a broom stick", "Apparition and Disapparition (being able to materialize and dematerialize at will)", "Every area of magic I can"},
            //4: R,G,S,H
            {"The power to read minds", "The power to change your appearance at will", "The power of invisibility", "The power to speak to animals"},
            //5: R,H,G,S
            {"Unicorn Tail Hair", "Veela Hair", "Phoenix Tailfeather", "Dragon Heartstring"},
            //6: H,S,G,R
            {"Merpeople", "Vampires", "Centaurs", "Goblins"},
            //7: S,H,R,G
            {"Feared", "Trusted", "Praised", "Imitated"},
            //8: R,S,G,H
            {"Suggest drawing lots to decide which of you will fight", "Suggest that all three of you should fight (without telling the troll)", "Volunteer to fight", "Attempt to confuse the troll into letting all three of you pass without fighting"},
            //9: G,R,S,H
            {"The twisting, leaf-strewn path through woods", "The cobbled street lined with ancient buildings", "The narrow, dark, lantern-lit alley", "The wide, sunny, grassy lane"},
            //10: H,G,R,S
            {"You are talking in public when all of a sudden your voice starts to get squeakier and stranger. Everyone begins to point and laugh, mocking your ridiculous voice.", "You are standing somewhere very high when you notice the surface is incredibly smooth. There are no hand or footholds, and no barrier to keep you from plummeting down.", "You are locked in a dark windowless room but you can make out an eye staring at you through the keyhole of the door.", "You awaken to find that everyone has forgotten who you are."},
            //11: G,S,H,R
            {"Draw you wand and stand your ground", "Withdraw into the shadows to hide and wait while mentally reviewing appropriate offensive and defensive spells", "Draw your wand and search for the noise", "Proceed cautiously with one hand on your concealed wand, keeping an eye out for anything suspicious"},
            //12: S,G,H,R
            {"Agree, and ask whether they’d like a free sample of a jinx?", "Agree, and walk away, leaving them to wonder whether you are bluffing", "Ask them why they think so", "Tell them that you are worried about their mental health and offer to call a doctor"},
            //13: H,S,R,G
            {"Love", "Power", "Wisdom", "Glory"}
    };

    private Integer answerScore[][] = {
            //G=1, H=2, R=3, S=4
            //1: G,R,H,S
            {1,3,2,4},
            //2: H,S,R,G
            {2,4,3,1},
            //3: S,G,H,R
            {4,1,2,3},
            //4: R,G,S,H
            {3,1,4,2},
            //5: R,H,G,S
            {3,2,1,4},
            //6: H,S,G,R
            {2,4,1,3},
            //7: S,H,R,G
            {4,2,3,1},
            //8: R,S,G,H
            {3,4,1,2},
            //9: G,R,S,H
            {1,3,4,2},
            //10: H,G,R,S
            {2,1,3,4},
            //11: G,S,H,R
            {1,4,2,3},
            //12: S,G,H,R
            {4,1,2,3},
            //13: H,S,R,G
            {2,4,3,1}
    };

    public String getQuestion(int a){
        return sortingQuestions[a];
    }

    public String getChoice1(int a) {
        return sortingChoices[a][0];
    }
    public String getChoice2(int a){
        return sortingChoices[a][1];
    }
    public String getChoice3(int a){
        return sortingChoices[a][2];
    }
    public String getChoice4(int a){
        return sortingChoices[a][3];
    }

    public Integer getScore1(int a){
        return answerScore[a][0];
    }
    public Integer getScore2(int a){
        return answerScore[a][1];
    }
    public Integer getScore3(int a){
        return answerScore[a][2];
    }
    public Integer getScore4(int a){
        return answerScore[a][3];
    }
}
