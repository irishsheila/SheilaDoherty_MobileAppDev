package com.example.sheila.sortinghat;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class HouseAnnouncement extends AppCompatActivity {

    private int finalScore;
    private String nameValue;
    public String finalHouse;
    public String motto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_house_announcement);

        Intent intent3 = getIntent();
        finalScore = intent3.getIntExtra("score", finalScore);
        nameValue = intent3.getStringExtra("userName");
        Log.i("scoreReceived", Integer.toString(finalScore));
        Log.i("nameReceived", nameValue);
        TextView messageView = (TextView) findViewById(R.id.scoreTextView);
        TextView houseView = (TextView) findViewById(R.id.houseTextView);
        TextView mottoView = (TextView) findViewById(R.id.mottoTextView);
        ImageView hogwartsHouse = (ImageView) findViewById(R.id.imageView2);

        if (finalScore <= 16){
            finalHouse = "Gryffindor";
            motto = "Where Dwell the Brave at Heart!";
            hogwartsHouse.setImageResource(R.drawable.gryffindor);
        }
        if (finalScore > 16 & finalScore <= 26){
            finalHouse = "Hufflepuff";
            motto = "Those Patient Hufflepuffs are True and Unafraid of Toil";
            hogwartsHouse.setImageResource(R.drawable.hufflepuff);
        }
        if (finalScore > 26 & finalScore <= 36){
            finalHouse = "Ravenclaw";
            motto = "Wit Beyond Measure is Man's Greatest Treasure.";
            hogwartsHouse.setImageResource(R.drawable.ravenclaw);
        }
        if (finalScore > 36){
            finalHouse = "Slytherin";
            motto = "Slytherin Will Help You on Your Way to Greatness.";
            hogwartsHouse.setImageResource(R.drawable.slytherin);
        }
        messageView.setText("Welcome to Hogwarts, " + nameValue + "! Your house is ");
        houseView.setText(finalHouse + "!");
        mottoView.setText(motto);

        final Button restart = (Button) findViewById(R.id.restart);

        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                Intent intent = getBaseContext().getPackageManager().
                        getLaunchIntentForPackage(getBaseContext().getPackageName());
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                finish();
                startActivity(intent);
            }
        };
        restart.setOnClickListener(onclick);
    }
}
