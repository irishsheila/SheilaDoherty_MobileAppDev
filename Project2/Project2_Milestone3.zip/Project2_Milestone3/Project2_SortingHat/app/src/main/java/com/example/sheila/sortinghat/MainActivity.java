package com.example.sheila.sortinghat;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Button answer1, answer2, answer3, answer4;
    TextView quizQuestion;

    private Questions mQuestions = new Questions();
    private int mAnswer1;
    private int mAnswer2;
    private int mAnswer3;
    private int mAnswer4;
    private int mScore = 0;
    private int mQuestionNumber = 0;
    private String nameValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent1 = getIntent();
        nameValue = intent1.getStringExtra("userName");

        answer1 = (Button)findViewById(R.id.answer1);
        answer2 = (Button)findViewById(R.id.answer2);
        answer3 = (Button)findViewById(R.id.answer3);
        answer4 = (Button)findViewById(R.id.answer4);

        quizQuestion = (TextView)findViewById(R.id.quizQuestion);
        final Intent intent2 = new Intent(this, HouseAnnouncement.class);

        updateQuestion(mQuestionNumber);

        answer1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mScore = mScore + mAnswer1;
                Log.i("mScore", Integer.toString(mScore));
                mQuestionNumber++;
                if (mQuestionNumber < 11) {
                    updateQuestion(mQuestionNumber);
                }
                else{
                    intent2.putExtra("score", mScore);
                    intent2.putExtra("userName", nameValue);
                    Log.i("scoreSent", Integer.toString(mScore));
                    startActivity(intent2);
                }
            }
        });
        answer2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mScore = mScore + mAnswer2;
                Log.i("mScore", Integer.toString(mScore));
                mQuestionNumber++;
                if (mQuestionNumber < 11) {
                    updateQuestion(mQuestionNumber);
                }
                else{
                    intent2.putExtra("score", mScore);
                    intent2.putExtra("userName", nameValue);
                    Log.i("scoreSent", Integer.toString(mScore));
                    startActivity(intent2);
                }
            }
        });
        answer3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mScore = mScore + mAnswer3;
                Log.i("mScore", Integer.toString(mScore));
                mQuestionNumber++;
                if (mQuestionNumber < 11) {
                    updateQuestion(mQuestionNumber);
                }
                else{
                    intent2.putExtra("score", mScore);
                    intent2.putExtra("userName", nameValue);
                    Log.i("scoreSent", Integer.toString(mScore));
                    startActivity(intent2);
                }
            }
        });
        answer4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mScore = mScore + mAnswer4;
                Log.i("mScore", Integer.toString(mScore));
                mQuestionNumber++;
                if (mQuestionNumber < 11) {
                    updateQuestion(mQuestionNumber);
                }
                else{
                    intent2.putExtra("score", mScore);
                    intent2.putExtra("userName", nameValue);
                    Log.i("scoreSent", Integer.toString(mScore));
                    startActivity(intent2);
                }
            }
        });

        // recovering the instance state
        if (savedInstanceState !=null){
            nameValue = savedInstanceState.getString("name");
            mAnswer1 = savedInstanceState.getInt("answer1");
            mAnswer2 = savedInstanceState.getInt("answer2");
            mAnswer3 = savedInstanceState.getInt("answer3");
            mAnswer4 = savedInstanceState.getInt("answer4");
            mScore = savedInstanceState.getInt("score");
            Log.i("setScoreValue", Integer.toString(mScore));
            mQuestionNumber = savedInstanceState.getInt("question");

            quizQuestion.setText(mQuestions.getQuestion(mQuestionNumber));
            Log.i("setQuestionValue", Integer.toString(mQuestionNumber));

            answer1.setText(mQuestions.getChoice1(mQuestionNumber));
            Log.i("setAnswer1Value", Integer.toString(mAnswer1));

            answer2.setText(mQuestions.getChoice2(mQuestionNumber));
            Log.i("setAnswer2Value", Integer.toString(mAnswer2));

            answer3.setText(mQuestions.getChoice3(mQuestionNumber));
            Log.i("setAnswer3Value", Integer.toString(mAnswer3));

            answer4.setText(mQuestions.getChoice4(mQuestionNumber));
            Log.i("setAnswer4Value", Integer.toString(mAnswer4));
        }
    }

    private void updateQuestion(int num){
        quizQuestion.setText(mQuestions.getQuestion(num));
        answer1.setText(mQuestions.getChoice1(num));
        answer2.setText(mQuestions.getChoice2(num));
        answer3.setText(mQuestions.getChoice3(num));
        answer4.setText(mQuestions.getChoice4(num));

        mAnswer1 = mQuestions.getScore1(num);
        Log.i("answerVal1", Integer.toString(mAnswer1));
        mAnswer2 = mQuestions.getScore2(num);
        Log.i("answerVal2", Integer.toString(mAnswer2));
        mAnswer3 = mQuestions.getScore3(num);
        Log.i("answerVal3", Integer.toString(mAnswer3));
        mAnswer4 = mQuestions.getScore4(num);
        Log.i("answerVal4", Integer.toString(mAnswer4));
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString("name", nameValue);

        outState.putInt("answer1", mAnswer1);
        Log.i("savedAnswer1Value", Integer.toString(mAnswer1));
        outState.putInt("answer2", mAnswer2);
        Log.i("savedAnswer2Value", Integer.toString(mAnswer2));
        outState.putInt("answer3", mAnswer3);
        Log.i("savedAnswer3Value", Integer.toString(mAnswer3));
        outState.putInt("answer4", mAnswer4);
        Log.i("savedAnswer4Value", Integer.toString(mAnswer1));
        outState.putInt("score", mScore);
        Log.i("savedScoreValue", Integer.toString(mScore));
        outState.putInt("question", mQuestionNumber);
        Log.i("savedQuestionNumValue", Integer.toString(mQuestionNumber));
        super.onSaveInstanceState(outState);
    }
}
