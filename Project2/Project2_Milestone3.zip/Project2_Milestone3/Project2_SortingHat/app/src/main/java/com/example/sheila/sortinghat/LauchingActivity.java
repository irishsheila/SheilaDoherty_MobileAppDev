package com.example.sheila.sortinghat;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LauchingActivity extends AppCompatActivity {
    private String nameValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lauching);

        final Button button = (Button) findViewById(R.id.button);
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                typeName(view);
            }
        };
        button.setOnClickListener(onclick);

        // recovering the instance state
        if (savedInstanceState !=null){
            nameValue = savedInstanceState.getString("name");
        }
    }

    public void typeName(View view){
        EditText name = (EditText) findViewById(R.id.editText);
        nameValue = name.getText().toString();
        if (nameValue.matches("")) {
            Toast.makeText(this, "The Sorting Hat needs your name to continue", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("userName", nameValue);
        startActivity(intent);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString("name", nameValue);
        super.onSaveInstanceState(outState);
    }
}
