//
//  ViewController.swift
//  heightcalculator
//
//  Created by Sheila Doherty on 10/8/17.
//  Copyright © 2017 Sheila Doherty. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet weak var firstName: UILabel!
    @IBOutlet weak var enterHeight: UILabel!
    @IBOutlet weak var htFeet: UILabel!
    @IBOutlet weak var htInches: UILabel!
    @IBOutlet weak var hiName: UILabel!
    @IBOutlet weak var htDisplay: UILabel!
    @IBOutlet weak var enterName: UITextField!
    @IBOutlet weak var enterFeet: UITextField!
    @IBOutlet weak var enterInches: UITextField!

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        let nextTag = textField.tag+1
        let nextResponder = textField.superview?.viewWithTag(nextTag) as UIResponder!
        
        if (nextResponder != nil){
            nextResponder?.becomeFirstResponder()
        }
        else{
            textField.resignFirstResponder()
        }
        return false
    }
    
    override func viewDidLoad() {
        enterName.delegate = self
        enterFeet.delegate = self
        enterInches.delegate = self
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }

    func updateDisplay(){
        var displayName: String
        var displayHeight: Int
        
        if enterName.text!.isEmpty {
            displayName = " "
        }
        else {
            displayName = "Hi \(enterName.text!)!"
        }
        if enterFeet.text!.isEmpty {
            displayHeight = 0
        }
        else if enterInches.text!.isEmpty {
            displayHeight = 0
        }
        else {
            displayHeight = Int(enterFeet.text!)! * 12 + Int(enterInches.text!)!
        }
        
        let ftEntry = enterFeet.text
        let inEntry = enterInches.text
        
        if !(ftEntry?.isEmpty)! && (inEntry?.isEmpty)! {
            let alert = UIAlertController(title: "Warning", message: "You must enter a value of zero or greater for inches", preferredStyle: UIAlertControllerStyle.alert)
            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: nil)
            alert.addAction(cancelAction)
            let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: {action in
                self.enterInches.text = "0"
                self.updateDisplay()
            })
            alert.addAction(okAction)
            present(alert, animated: true, completion: nil)
        }
        
        hiName.text = displayName
        htDisplay.text = "You are \(displayHeight) inches tall"
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        updateDisplay()
    }
}



