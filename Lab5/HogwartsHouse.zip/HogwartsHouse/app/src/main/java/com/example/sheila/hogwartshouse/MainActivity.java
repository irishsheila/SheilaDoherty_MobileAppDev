package com.example.sheila.hogwartshouse;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void findHouse(View view) {
        EditText name = (EditText) findViewById(R.id.editText);
        String nameValue = name.getText().toString();
        ImageView hogwartsHouse = (ImageView) findViewById(R.id.imageView2);

        ToggleButton toggle = (ToggleButton) findViewById(R.id.toggleButton);

        Spinner spell = (Spinner) findViewById(R.id.spinner);
        String spellType = String.valueOf(spell.getSelectedItem());

        RadioGroup wand = (RadioGroup) findViewById(R.id.radioGroup2);
        int wand_id = wand.getCheckedRadioButtonId();

        CheckBox gCheckbox = (CheckBox) findViewById(R.id.checkBox);
        boolean grif = gCheckbox.isChecked();
        CheckBox hCheckbox = (CheckBox) findViewById(R.id.checkBox2);
        boolean huff = hCheckbox.isChecked();
        CheckBox rCheckbox = (CheckBox) findViewById(R.id.checkBox3);
        boolean raven = rCheckbox.isChecked();
        CheckBox sCheckbox = (CheckBox) findViewById(R.id.checkBox4);
        boolean slyth = sCheckbox.isChecked();

        boolean bloodStatus = toggle.isChecked();

        String house;
        if (wand_id == -1) {
            Context context = getApplicationContext();
            CharSequence text = "Please select a wand type";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
        else {
            if (bloodStatus) {//pure blood - toggle
                if (wand_id == R.id.radioButton) { //Dragon Heartstring
                    if (grif) {
                        switch (spellType) {
                            case "Protego!":
                                house = "Hufflepuff";
                                hogwartsHouse.setImageResource(R.drawable.hufflepuff);
                                break;
                            case "Crucio!":
                                house = "Slytherin";
                                hogwartsHouse.setImageResource(R.drawable.slytherin);
                                break;
                            default:
                                house = "Gryffindor";
                                hogwartsHouse.setImageResource(R.drawable.gryffindor);
                        }
                    } else if (huff) {
                        switch (spellType) {
                            case "Crucio!":
                                house = "Slytherin";
                                hogwartsHouse.setImageResource(R.drawable.slytherin);
                                break;
                            default:
                                house = "Hufflepuff";
                                hogwartsHouse.setImageResource(R.drawable.hufflepuff);
                        }
                    } else if (raven) {
                        switch (spellType) {
                            case "Crucio!":
                                house = "Slytherin";
                                hogwartsHouse.setImageResource(R.drawable.slytherin);
                                break;
                            default:
                                house = "Ravenclaw";
                                hogwartsHouse.setImageResource(R.drawable.ravenclaw);
                        }
                    } else {
                        switch (spellType) {
                            case "Expelliarmus!":
                                house = "Gryffindor";
                                hogwartsHouse.setImageResource(R.drawable.gryffindor);
                                break;
                            default:
                                house = "Slytherin";
                                hogwartsHouse.setImageResource(R.drawable.slytherin);
                        }

                    }

                }
                if (wand_id == R.id.radioButton2) { //Phoenix Feather
                    if (grif) {
                        switch (spellType) {
                            case "Stupify!":
                                house = "Ravenclaw";
                                hogwartsHouse.setImageResource(R.drawable.ravenclaw);
                                break;
                            case "Crucio!":
                                house = "Slytherin";
                                hogwartsHouse.setImageResource(R.drawable.slytherin);
                                break;
                            default:
                                house = "Gryffindor";
                                hogwartsHouse.setImageResource(R.drawable.gryffindor);
                        }
                    } else if (huff) {
                        switch (spellType) {
                            case "Crucio!":
                                house = "Slytherin";
                                //hogwartsHouse.setImageResource(R.drawable.slytherin);
                                break;
                            default:
                                house = "Gryffindor";
                                hogwartsHouse.setImageResource(R.drawable.gryffindor);
                        }
                    } else if (raven) {
                        switch (spellType) {
                            case "Expelliarmus!":
                                house = "Gryffindor";
                                hogwartsHouse.setImageResource(R.drawable.gryffindor);
                                break;
                            default:
                                house = "Ravenclaw";
                                hogwartsHouse.setImageResource(R.drawable.ravenclaw);
                        }
                    } else {
                        switch (spellType) {
                            case "Expelliarmus!":
                                house = "Gryffindor";
                                hogwartsHouse.setImageResource(R.drawable.gryffindor);
                                break;
                            default:
                                house = "Slytherin";
                                hogwartsHouse.setImageResource(R.drawable.slytherin);
                        }

                    }

                }
                if (wand_id == R.id.radioButton3) { //Unicorn Hair
                    if (grif) {
                        switch (spellType) {
                            case "Stupify!":
                                house = "Gryffindor";
                                hogwartsHouse.setImageResource(R.drawable.gryffindor);
                                break;
                            case "Crucio!":
                                house = "Slytherin";
                                hogwartsHouse.setImageResource(R.drawable.slytherin);
                                break;
                            default:
                                house = "Hufflepuff";
                                hogwartsHouse.setImageResource(R.drawable.hufflepuff);
                        }
                    } else if (huff) {
                        switch (spellType) {
                            case "Crucio!":
                                house = "Slytherin";
                                hogwartsHouse.setImageResource(R.drawable.slytherin);
                                break;
                            default:
                                house = "Hufflepuff";
                                hogwartsHouse.setImageResource(R.drawable.hufflepuff);
                        }
                    } else if (raven) {
                        switch (spellType) {
                            case "Protego!":
                                house = "Gryffindor";
                                hogwartsHouse.setImageResource(R.drawable.gryffindor);
                                break;
                            default:
                                house = "Ravenclaw";
                                hogwartsHouse.setImageResource(R.drawable.ravenclaw);
                        }
                    } else {
                        switch (spellType) {
                            case "Expelliarmus!":
                                house = "Gryffindor";
                                hogwartsHouse.setImageResource(R.drawable.gryffindor);
                                break;
                            default:
                                house = "Slytherin";
                                hogwartsHouse.setImageResource(R.drawable.slytherin);
                        }
                    }
                } else { //Thestral Hair
                    if (grif) {
                        switch (spellType) {
                            case "Protego!":
                                house = "Gryffindor";
                                hogwartsHouse.setImageResource(R.drawable.gryffindor);
                                break;
                            default:
                                house = "Slytherin";
                                hogwartsHouse.setImageResource(R.drawable.slytherin);
                        }
                    } else if (huff) {
                        switch (spellType) {
                            case "Crucio!":
                                house = "Slytherin";
                                hogwartsHouse.setImageResource(R.drawable.slytherin);
                                break;
                            default:
                                house = "Hufflepuff";
                                hogwartsHouse.setImageResource(R.drawable.hufflepuff);
                        }
                    } else if (raven) {
                        switch (spellType) {
                            case "Protego!":
                                house = "Gryffindor";
                                hogwartsHouse.setImageResource(R.drawable.gryffindor);
                                break;
                            default:
                                house = "Slytherin";
                                hogwartsHouse.setImageResource(R.drawable.slytherin);
                        }
                    } else {
                        house = "Slytherin";
                        hogwartsHouse.setImageResource(R.drawable.slytherin);
                    }
                }
            } else { //muggle born - toggle
                if (wand_id == R.id.radioButton) { //Dragon Heartstring
                    if (grif) {
                        switch (spellType) {
                            case "Protego!":
                                house = "Ravenclaw";
                                hogwartsHouse.setImageResource(R.drawable.ravenclaw);
                                break;
                            default:
                                house = "Gryffindor";
                                hogwartsHouse.setImageResource(R.drawable.gryffindor);
                        }
                    } else if (huff) {
                        switch (spellType) {
                            case "Expelliarmus!":
                                house = "Gryffindor";
                                hogwartsHouse.setImageResource(R.drawable.gryffindor);
                                break;
                            default:
                                house = "Hufflepuff";
                                hogwartsHouse.setImageResource(R.drawable.hufflepuff);
                        }
                    } else if (raven) {
                        switch (spellType) {
                            case "Stupify!":
                                house = "Gryffindor";
                                hogwartsHouse.setImageResource(R.drawable.gryffindor);
                                break;
                            default:
                                house = "Ravenclaw";
                                hogwartsHouse.setImageResource(R.drawable.ravenclaw);
                        }
                    } else {
                        house = "Hufflepuff";
                        hogwartsHouse.setImageResource(R.drawable.hufflepuff);
                    }

                }
                if (wand_id == R.id.radioButton2) { //Phoenix Feather
                    if (grif) {
                        switch (spellType) {
                            case "Protego!":
                                house = "Ravenclaw";
                                hogwartsHouse.setImageResource(R.drawable.ravenclaw);
                                break;
                            default:
                                house = "Gryffindor";
                                hogwartsHouse.setImageResource(R.drawable.gryffindor);
                        }
                    } else if (huff) {
                        switch (spellType) {
                            case "Crucio!":
                                house = "Gryffindor";
                                hogwartsHouse.setImageResource(R.drawable.gryffindor);
                                break;
                            default:
                                house = "Hufflepuff";
                                hogwartsHouse.setImageResource(R.drawable.hufflepuff);
                        }
                    } else if (raven) {
                        switch (spellType) {
                            case "Expelliarmus!":
                                house = "Gryffindor";
                                hogwartsHouse.setImageResource(R.drawable.gryffindor);
                                break;
                            default:
                                house = "Ravenclaw";
                                hogwartsHouse.setImageResource(R.drawable.ravenclaw);
                        }
                    } else {
                        house = "Gryffindor";
                        hogwartsHouse.setImageResource(R.drawable.gryffindor);

                    }

                }
                if (wand_id == R.id.radioButton3) { //Unicorn Hair
                    if (grif) {
                        switch (spellType) {
                            case "Crucio!":
                                house = "Ravenclaw";
                                hogwartsHouse.setImageResource(R.drawable.ravenclaw);
                                break;
                            default:
                                house = "Gryffindor";
                                hogwartsHouse.setImageResource(R.drawable.gryffindor);
                        }
                    } else if (huff) {
                        switch (spellType) {
                            case "Expelliarmus!":
                                house = "Ravenclaw";
                                hogwartsHouse.setImageResource(R.drawable.ravenclaw);
                                break;
                            default:
                                house = "Hufflepuff";
                                hogwartsHouse.setImageResource(R.drawable.hufflepuff);
                        }
                    } else if (raven) {
                        switch (spellType) {
                            case "Stupify!":
                                house = "Gryffindor";
                                hogwartsHouse.setImageResource(R.drawable.gryffindor);
                                break;
                            default:
                                house = "Ravenclaw";
                                hogwartsHouse.setImageResource(R.drawable.ravenclaw);
                        }
                    } else {
                        house = "Ravenclaw";
                        hogwartsHouse.setImageResource(R.drawable.ravenclaw);
                    }
                } else { //Thestral Hair
                    if (grif) {
                        switch (spellType) {
                            case "Crucio!":
                                house = "Ravenclaw";
                                hogwartsHouse.setImageResource(R.drawable.gryffindor);
                                break;
                            default:
                                house = "Gryffindor";
                                hogwartsHouse.setImageResource(R.drawable.gryffindor);
                        }
                    } else if (huff) {
                        switch (spellType) {
                            case "Expelliarmus!":
                                house = "Gryffindor";
                                hogwartsHouse.setImageResource(R.drawable.gryffindor);
                                break;
                            default:
                                house = "Hufflepuff";
                                hogwartsHouse.setImageResource(R.drawable.hufflepuff);
                        }
                    } else if (raven) {
                        switch (spellType) {
                            case "Protego!":
                                house = "Hufflepuff";
                                hogwartsHouse.setImageResource(R.drawable.hufflepuff);
                                break;
                            default:
                                house = "Ravenclaw";
                                hogwartsHouse.setImageResource(R.drawable.ravenclaw);
                        }
                    } else {
                        house = "Hufflepuff";
                        hogwartsHouse.setImageResource(R.drawable.hufflepuff);
                    }
                }
            }

            TextView messageText = (TextView) findViewById(R.id.message);
            messageText.setText("Congratulations " + nameValue + ", you're in " + house + " house!");
        }
    }
}
