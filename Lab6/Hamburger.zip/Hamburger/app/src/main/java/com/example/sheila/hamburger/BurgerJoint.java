package com.example.sheila.hamburger;

/**
 * Created by Sheila on 11/21/17.
 */

public class BurgerJoint {
    private String burgerJoint;
    private String burgerJointURL;

    private void setBurgerInfo(Integer burgerType){
        switch(burgerType){
            case 0: //organic
                burgerJoint = "Larkburger";
                burgerJointURL = "http://larkburger.com";
                break;
            case 1: //handmade
                burgerJoint = "Smashburger";
                burgerJointURL = "http://smashburger.com";
                break;
            case 2: //restaurant
                burgerJoint = "Red Robin";
                burgerJointURL = "https://www.redrobin.com";
                break;
            case 3: //popular
                burgerJoint = "In N Out";
                burgerJointURL = "http://www.in-n-out.com";
                break;
            case 4: //cheap
                burgerJoint = "McDonald's";
                burgerJointURL = "https://www.mcdonalds.com/us/en-us.html";
                break;
            case 5: //chicken
                burgerJoint = "Chick-Fil-A";
                burgerJointURL = "https://www.chick-fil-a.com";
                break;
            default:
                burgerJoint = "none";
                burgerJointURL = "https://www.yelp.com/search?cflt=burgers&find_loc=Boulder%2C+CO";
        }
    }

    public void setBurgerJoint(Integer burgerType){
        setBurgerInfo(burgerType);
    }

    public void setBurgerJointURL(Integer burgerType){
        setBurgerJointURL(burgerType);
    }

    public String getBurgerJoint(){
        return burgerJoint;
    }

    public String getBurgerJointURL(){
        return burgerJointURL;
    }
}
