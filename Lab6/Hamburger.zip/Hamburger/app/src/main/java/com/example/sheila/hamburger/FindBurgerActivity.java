package com.example.sheila.hamburger;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

public class FindBurgerActivity extends AppCompatActivity {

    private BurgerJoint myBurgerJoint = new BurgerJoint();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_burger);
        //get button
        final Button button = (Button)findViewById(R.id.button);
        //create listener
        View.OnClickListener onclick = new View.OnClickListener(){
          public void onClick(View view){
              findBurger(view);
          }
        };
        //add listener to the button
        button.setOnClickListener(onclick);
    }

    public void findBurger(View view){
        //get spinner
        Spinner typeSpinner = (Spinner)findViewById(R.id.spinner);
        //get spinner item array position
        Integer type = typeSpinner.getSelectedItemPosition();
        //set the burger joint
        myBurgerJoint.setBurgerJoint(type);
        //get suggested burger joint
        String suggestedBurgerJoint = myBurgerJoint.getBurgerJoint();
        //get suggested burger joint URL
        String suggestedBurgerJointURL = myBurgerJoint.getBurgerJointURL();
        Log.i("joint", suggestedBurgerJoint);
        Log.i("url", suggestedBurgerJointURL);

        Intent intent = new Intent(this, ReceiveBurgerActivity.class);
        //pass data
        intent.putExtra("burgerJointName", suggestedBurgerJoint);
        intent.putExtra("burgerJointURL", suggestedBurgerJointURL);
        //start the intent
        startActivity(intent);
    }
}
