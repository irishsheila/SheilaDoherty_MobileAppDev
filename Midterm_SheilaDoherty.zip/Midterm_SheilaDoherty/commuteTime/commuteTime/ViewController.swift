//
//  ViewController.swift
//  commuteTime
//
//  Created by Sheila Doherty on 10/19/17.
//  Copyright © 2017 Sheila Doherty. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var showMonthlySwitch: UISwitch!
    @IBAction func updateComOutput(_ sender: UISwitch) {
        if showMonthlySwitch.isOn {
            updateTimeGas(monthly: 20, gasMilage: 24, mPH: 20, wait: 0)
        } else {
            updateTimeGas(monthly: 1, gasMilage: 24, mPH: 20, wait: 0)
            
        }
    }

    @IBOutlet weak var comMilesText: UITextField!
    @IBOutlet weak var comTime: UILabel!
    @IBOutlet weak var gasAmt: UILabel!
    @IBAction func commutePressed(_ sender: UIButton) {
        updateTimeGas(monthly: 1, gasMilage: 24, mPH: 20, wait: 0)
    }
    @IBOutlet weak var gasInTankLabel: UILabel!
    @IBAction func gasInTankSlider(_ sender: UISlider) {
        let tankValue=sender.value
        gasInTankLabel.text="\(String(tankValue)) gallons"
        
    }
    @IBOutlet weak var commuteControl: UISegmentedControl!
    
    @IBAction func changeComType(_ sender: UISegmentedControl) {
        if commuteControl.selectedSegmentIndex==1 {
            if showMonthlySwitch.isOn {
                updateTimeGas(monthly: 20, gasMilage: 0, mPH: 12, wait: 5)
            } else {
                updateTimeGas(monthly: 1, gasMilage: 0, mPH: 12, wait: 5)
            }
        }
        else if commuteControl.selectedSegmentIndex==2 {
            if showMonthlySwitch.isOn {
                updateTimeGas(monthly: 20, gasMilage: 0, mPH: 10, wait: 0)
            } else {
                updateTimeGas(monthly: 1, gasMilage: 0, mPH: 10, wait: 0)
            }
            
        }
        else{
            if showMonthlySwitch.isOn {
                updateTimeGas(monthly: 20, gasMilage: 24, mPH: 20, wait: 0)
            } else {
                updateTimeGas(monthly: 1, gasMilage: 24, mPH: 20, wait: 0)
            }
            
        }
    }

    override func viewDidLoad() {
        comMilesText.delegate = self
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true;
    }
    
    func updateTimeGas(monthly: Float, gasMilage: Float, mPH: Float, wait: Float){
        var timeCommute: Float
        var gasPurchase: Float
        //let gasMilage: Float = 24
        //let mPH: Float = 20
        if comMilesText.text!.isEmpty{
            timeCommute = 0.0
            gasPurchase = 0.0
        }
        else{
            timeCommute = Float(comMilesText.text!)! / mPH * 60 * monthly + wait
            if gasMilage == 0 {
                gasPurchase = 0
            }
            else{
                
            gasPurchase = Float(comMilesText.text!)! / gasMilage * monthly + wait
            }
            
        }
        let stringcomTime = String(describing: timeCommute)
        let stringgasAmt = String(describing: gasPurchase)
        comTime.text = "\(stringcomTime)  minutes"
        gasAmt.text = "\(stringgasAmt) gallons"
        
    }

}

